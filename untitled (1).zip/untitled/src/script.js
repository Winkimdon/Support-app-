let users = [];
let currentUser = null;
let balance = 0;

function signUp() {
    const phone = document.getElementById('signUpPhone').value;
    const password = document.getElementById('signUpPassword').value;
    const coupon = document.getElementById('signUpCoupon').value;

    if (coupon !== 'zxcvbnmdfghj') {
        document.getElementById('signUpMessage').innerText = "Invalid coupon code.";
        return;
    }

    users.push({ phone, password });
    document.getElementById('signUpPage').classList.add('hidden');
    document.getElementById('loginPage').classList.remove('hidden');
}

function login() {
    const phone = document.getElementById('loginPhone').value;
    const password = document.getElementById('loginPassword').value;
    const user = users.find(u => u.phone === phone && u.password === password);

    if (!user) {
        document.getElementById('loginMessage').innerText = "Invalid credentials.";
        return;
    }

    currentUser = user;
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('mainPage').classList.remove('hidden');
}

function goToVendor() {
    document.getElementById('signUpPage').classList.add('hidden');
    document.getElementById('vendorPage').classList.remove('hidden');
}

function backToSignUp() {
    document.getElementById('vendorPage').classList.add('hidden');
    document.getElementById('signUpPage').classList.remove('hidden');
}

function goToTikTokPage() {
    document.getElementById('mainPage').classList.add('hidden');
    document.getElementById('tikTokPage').classList.remove('hidden');
}

function submitTikTok() {
    const link = document.getElementById('tikTokLink').value;
    const views = document.getElementById('tikTokViews').value;
    alert(`Submitted TikTok link: ${link}, Views: ${views}`);
}

function goToTaskPage() {
    document.getElementById('mainPage').classList.add('hidden');
    document.getElementById('taskPage').classList.remove('hidden');
    generateTasks();
}

function generateTasks() {
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = "";

    for (let i = 1; i <= 5; i++) {
        const button = document.createElement('button');
        button.innerText = `Task ${i}: Earn $${i}`;
        button.onclick = () => {
            alert("Ad is being displayed.");
            balance += i;
        };
        taskList.appendChild(button);
    }
}

function showBalance() {
    alert(`Your current balance is $${balance}`);
}

function withdraw() {
    if (balance >= 30) {
        balance -= 30;
        alert("Withdrawal successful!");
    } else {
        alert("Minimum withdrawal amount is $30.");
    }
}

function handleWithdraw() {
    const amount = parseFloat(document.getElementById("withdrawAmount").value);
    const name = document.getElementById("name").value.trim();
    const accountNumber = document.getElementById("accountNumber").value.trim();
    const bankName = document.getElementById("bankName").value.trim();
    const message = document.getElementById("withdrawMessage");

    // Minimum and maximum withdrawal validation
    if (!amount || amount < 30 || amount > 1000) {
        message.style.color = "red";
        message.innerText = "Amount must be between $30 and $1000.";
        return;
    }

    // Ensure all fields are filled
    if (!name || !accountNumber || !bankName) {
        message.style.color = "red";
        message.innerText = "All fields are required.";
        return;
    }

    // Show success message
    message.style.color = "green";
    message.innerText = `Withdrawal successful! Amount: $${amount}. Returning to Main Page...`;

    // Clear form after successful submission
    setTimeout(() => {
        document.getElementById("withdrawForm").reset();
        backToMain();
    }, 3000);
}

function backToMain() {
    document.querySelectorAll('.page').forEach(page => page.classList.add('hidden'));
    document.getElementById('mainPage').classList.remove('hidden');
}